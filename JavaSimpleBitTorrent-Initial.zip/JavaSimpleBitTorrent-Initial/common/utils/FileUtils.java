package common.utils;

import java.util.Map;

public class FileUtils {

	public static Map<String, String> listFilesInFolder(String folderPath) {
		// TODO: List files in folder
		// 1. Create folder object
		// 2. Get list of files
		// 3. Calculate MD5 hash for each file
		// 4. Return map of filename to hash
		throw new UnsupportedOperationException("List files in folder not implemented yet");
	}

	public static String getSortedFileList(Map<String, String> files) {
		// TODO: Get sorted file list
		// 1. Check if files map is empty
		// 2. Sort file names
		// 3. Create formatted string with names and hashes
		throw new UnsupportedOperationException("Get sorted file list not implemented yet");
	}
}
